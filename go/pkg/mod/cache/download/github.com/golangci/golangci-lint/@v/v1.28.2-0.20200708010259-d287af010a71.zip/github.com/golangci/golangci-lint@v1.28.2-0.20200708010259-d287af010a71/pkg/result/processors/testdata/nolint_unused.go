package testdata

var nolintVarcheck int // nolint:varcheck
