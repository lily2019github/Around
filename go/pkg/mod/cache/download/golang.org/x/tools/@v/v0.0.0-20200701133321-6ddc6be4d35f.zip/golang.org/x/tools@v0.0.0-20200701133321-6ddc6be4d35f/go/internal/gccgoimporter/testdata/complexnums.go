package complexnums

const NN = -1 - 1i
const NP = -1 + 1i
const PN = 1 - 1i
const PP = 1 + 1i
